package com.example.micro.sample.model;

public interface JsonKeys {
    String QUERY = "query";
    String PAGES = "pages";
    String TITLE = "title";
    String THUMBNAIL = "thumbnail";
    String SOURCE = "source";
    String WIDTH = "width";
    String HEIGHT = "height";
}
